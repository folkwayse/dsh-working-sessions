# dsh-working-sessions

DSH plugin: a **Working** group at the top of the sidebar listing sessions that
are genuinely active right now (live running status + subagent check + a
10-minute freshness guard against zombie `running` flags from crashed hosts).

- Click a row → opens the session (`ctx.uiWorkspace.openSession`)
- Green spinner per row, styled to match the native sidebar
- Renders *above* the original WorkspaceBrowser, which stays intact
- Empty when nothing is running — the group disappears entirely

## Install

```bash
dsh plugin install ./dsh-working-sessions
```

or add to your profile `package.json` bundles:

```json
"dsh-working-sessions": "link:../dsh-working-sessions"
```

## How it works

Shadows the `sidebar.workspaces` slot with a lower priority, copies the
original entry's `children/store/inject/locale` by reference, and renders a
class-component banner + the original browser underneath. Data comes from the
root standard hooks `useSessions((s) => s)` and `useSessionStatus((s) => s)`
(selector is mandatory — selector-less calls crash in WebKit with
`l is not a function`).
